class Zawodnik < ApplicationRecord
has_many:Trener
end

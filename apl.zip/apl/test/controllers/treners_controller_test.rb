require 'test_helper'

class TrenersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @trener = treners(:one)
  end

  test "should get index" do
    get treners_url
    assert_response :success
  end

  test "should get new" do
    get new_trener_url
    assert_response :success
  end

  test "should create trener" do
    assert_difference('Trener.count') do
      post treners_url, params: { trener: { Imie: @trener.Imie, Nazwisko: @trener.Nazwisko } }
    end

    assert_redirected_to trener_url(Trener.last)
  end

  test "should show trener" do
    get trener_url(@trener)
    assert_response :success
  end

  test "should get edit" do
    get edit_trener_url(@trener)
    assert_response :success
  end

  test "should update trener" do
    patch trener_url(@trener), params: { trener: { Imie: @trener.Imie, Nazwisko: @trener.Nazwisko } }
    assert_redirected_to trener_url(@trener)
  end

  test "should destroy trener" do
    assert_difference('Trener.count', -1) do
      delete trener_url(@trener)
    end

    assert_redirected_to treners_url
  end
end
